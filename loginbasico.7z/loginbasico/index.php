<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Login</title>
</head>
<style>

body{
    background-image: url(.//cat-spin.gif);
    
    
}

</style>
<body>   
    <?php

    require_once('usuario.php');


    $formData = filter_input_array(INPUT_POST, FILTER_DEFAULT);

    if(!empty($formData["logar"])){
        $createusuario = new usuario();
        $createusuario->formData = $formData;
      
        if(count($createusuario->validar())>0){
            header('location:teste.html');  
        
        }    
     }
    ?>
    <center>
    <main id="container">   
    <form id="login_form"  method="POST" action="">
            <!-- FORM HEADER -->
            <div id="form_header">
                <h1 style="font-size: xx-large; color: pink;">Login</h1>
                
            </div>
                <!-- EMAIL -->
                <div class="input-box">
                    <label for="email" style="font-size: xx-large; color: pink;">
                        E-mail
                        <div class="input-field">
                            
                            <input type="email" name="email" placeholder="E-mail" required><br>
                        </div>
                    </label>
                </div>
                
                <!-- PASSWORD -->
                <div class="input-box">
                    <label for="password" style="font-size: xx-large; color: pink;">
                        Senha
                        <div class="input-field">
                          
                            <input type="password" name="senha" placeholder="Senha" required>
                            
                        </div>
                    </label>
                    
                    </center>
            <!-- Cadastro Botão -->
            <center>
            <div>
                <br><br>
                <input style="font-size: xx-large; color: pink;" type="submit" id="login_button" value="Logar" name="logar"></input>
            
            </div>
            </center>
            

        </form>
    </main>
</body>
</html>